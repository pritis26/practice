package com.test.eventsManages;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventsManagesApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventsManagesApplication.class, args);
	}
}
