import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: "root"
})
export class ApixuService {
  constructor(private http: HttpClient) {}

  getWeather(location) {
    return this.http.get(
      "http://api.weatherstack.com/current?access_key=0c914ef697ade9bf2764ba57c648c7a1&query=" +
        location
    );
  }
}
